[ Please begin by replacing this file with "k2-README.txt" from the spec. ]
